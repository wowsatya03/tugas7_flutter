package com.example.tugas7

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
